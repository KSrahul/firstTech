new WOW().init();
//jQuery time
$(document).ready(function() {
// $("#firstContImg").fadeIn(700, function(){
//   $("#secondContImg").fadeIn(700, function(){
//    $("#thirdContImg").fadeIn(700);
//   });
// });
$('.testimon').owlCarousel({
  loop:true,
  margin:10,
  nav:true,
  navText: ["<img src='/Firstech/images/SLIDER arrow.svg'>","<img src='/Firstech/images/SLIDER arrow.svg'>"],
  mouseDrag: true,
  items : 2
})
});

$(".payment-btn").click(function() {
 $("#youtube-modal").removeClass("bp-hidden");
});

$(".bp-modal-close").click(function(){
  $("#youtube-modal").addClass("bp-hidden");
 });
$(document).mouseup(function(e) {
     var youtubeCont = $(".bp-modal-window");
         if (!youtubeCont.is(e.target) && youtubeCont.has(e.target).length === 0) {
             youtubeCont.parent().parent().addClass("bp-hidden");
                }
});

